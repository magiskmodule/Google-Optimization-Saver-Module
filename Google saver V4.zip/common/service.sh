#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 3
# Well-being
su -c "pm disable com.google.android.apps.wellbeing/.powerstate.impl.PowerStateJobService"
su -c "pm disable com.google.android.apps.wellbeing/androidx.work.impl.background.systemjob.SystemJobService"

sleep 3
# Tắt các dịch vụ thừa
su -c pm disable com.google.android.gms/.chimera.GmsIntentOperationService
su -c pm disable com.google.android.apps.messaging/.shared.analytics.recurringmetrics..AnalyticsAlarmReceiver
su -c pm disable com.google.android.location.internal.UPLOAD_ANALYTICS
su -c pm disable com.facebook.orca/com.facebook.analytics.apptatelogger.AppStateIntentService
su -c pm disable com.facebook.orca/com.facebook.analytics2.Logger.LollipopUploadService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService
su -c pm disable com.google.android.gms/NearbyMessagesService
su -c pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService
su -c pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService
su -c pm disable com.google.android.gms/com.google.android.gms.lockbox.LockboxService
su -c pm disable com.google.android.gms/.measurement.PackageMeasurementTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.auth.trustagent.GoogleTrustAgent
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.cache.CacheBrokerService
su -c pm disable com.google.android.gms/com.android.billingclient.api.ProxyBillingActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.measurement.GmpConversionTrackingBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.config.FlagsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.service.MeasurementBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.adinfo.AdvertisinglnfoContentProvider
su -c pm disable com.google.android.gms/com.google.android.gms.ads.AdRequestBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.jams.NegotiationService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.social.GcmSchedulerWakeupService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementTaskService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.PackageMeasurementReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.GservicesValueBrokerService
su -c pm disable com.google.android.gms/com.google.android.gms.ads.settings.AdsSettingsActivity
su -c pm disable com.google.android.gms/com.google.android.gms.ads.identifier.service.AdvertisingldNotificationService

sleep 3
# Tắt log theo dõi
su -c pm disable com.android.statementservice/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.maps/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.messaging/com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.apps.messaging/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.photos/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.restore/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.as/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.contacts/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.dialer/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gm/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.internal.PlayLogReportingService
su -c pm disable com.google.android.gms/com.google.android.gms.analytics.service.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.AnalyticsTaskService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.ar.core.services.AnalyticsService 
su -c pm disable com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.facebook.adspayments.analytics.ExperimentExposeService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.internal.GServicesChangedReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.internal.PlayLogReportingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.PlayLogMonitorIntervalService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.analytics.service.RefreshEnabledStateService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.common.analytics.CoreAnalyticsIntentService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.policy_sidecar_aps.common.analytics.CoreAnalyticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.gameanalytics.sdk.errorreporter.GameAnalyticsExceptionReportService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.samsung.android.hmt.vrsvc.receiver.AnalyticsLogReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.projection.gearhead/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.settings.intelligence/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.vanced.android.youtube/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.android.vending/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.apps.photos/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.calculator/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.gms/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementInstallReferrerReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementJobService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementContentProvider
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.measurement.AppMeasurementService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gearhead.telemetry.InstallReferrerReceiver
su -c pm disable com.google.android.projection.gearhead/com.google.android.gearhead.telemetry.InstallReferrerReceiver
su -c pm disable com.google.android.syncadapters.contacts/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.xiaomi.misettings/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.cameralite/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.gcs/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.helprtc/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.nbu.files/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.recorder/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.safetyhub/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.security.securityhub/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.wearables.maestro.companion/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.work.clouddpc/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.calendar/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.googlequicksearchbox/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.odad/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.tts/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.ar.core/com.google.ar.core.services.AnalyticsService
su -c pm disable com.google.ar.core/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.motorola.dolby.dolbyui/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.GoogleCameraEng/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.analytics.tracking.android.CampaignTrackingReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.analytics.tracking.android.CampaignTrackingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.CampaignTrackingService
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.gms.analytics.CampaignTrackingReceiver
su -c pm disable com.google.android.projection.gearhead/com.google.android.gms.analytics.CampaignTrackingService
su -c pm disable com.google.android.apps.docs/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.gms.policy_sidecar_aps/com.google.android.apps.messaging.shared.analytics.recurringmetrics.AnalyticsAlarmReceiver
su -c pm disable com.google.android.ims/androidx.work.impl.diagnostics.DiagnosticsReceiver

# Tắt các app bên thứ 3 ngăn theo dõi và hao pin
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.whatsapp/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.whatsapp/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.facebook.katana/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.facebook.katana/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.facebook.katana/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.facebook.katana/com.facebook.adspayments.analytics.ExperimentExposeService
su -c pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
su -c pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
su -c pm disable com.instagram.android/com.instagram.common.analytics.phoneid.InstagramPhoneIdRequestReceiver
su -c pm disable com.instagram.android/com.instagram.analytics.uploadscheduler.AnalyticsUploadAlarmReceiver
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.AlarmBasedUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.LollipopUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.GooglePlayUploadService
su -c pm disable com.instagram.android/com.facebook.analytics2.logger.HighPriUploadRetryReceiver
su -c pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateBroadcastReceiver
su -c pm disable com.instagram.android/com.facebook.analytics.appstatelogger.AppStateIntentService
su -c pm disable com.adobe.lrmobile/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.adobe.reader/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.adobe.scan.android/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.coolapk.market/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.digipom.easyvoicerecorder.pro/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.handmark.expressweather/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.instagram.android/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.mcdo.mcdonalds/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.mcdo.mcdonalds/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.microsoft.office.word/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.microsoft.teams/com.firebase.jobdispatcher.GooglePlayReceiver
su -c pm disable com.microsoft.teams/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.miui.gallery/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.miui.mediaeditor/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.yahoo.mobile.client.android.mail/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.yahoo.mobile.client.android.mail/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable ir.ilmili.telegraph/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable mx.com.miapp/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsService
su -c pm disable org.zwanoo.android.speedtest/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable pl.solidexplorer2/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.google.android.apps.magazines/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.alibaba.analytics.AnalyticsService
su -c pm disable com.facebook.analytics2.logger.service.LollipopUploadSafeService
su -c pm disable com.vanced.android.youtube/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.alibaba.aliexpresshd/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.amazon.mShop.android.shopping/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.cris87.miui/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.speedymovil.wire/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable qrcodereader.barcodescanner.scan.qrscanner/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable video.player.videoplayer/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.facebook.orca/com.facebook.messaging.internalprefs.MessengerAnalyticsActivity
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsService
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsReceiver
su -c pm disable com.facebook.orca/com.google.android.gms.analytics.AnalyticsJobService
su -c pm disable com.facebook.katana/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.ubercab/androidx.work.impl.diagnostics.DiagnosticsReceiver
su -c pm disable com.ubercab/com.braintreepayments.api.internal.AnalyticsIntentService

sleep 3

for i in $(ls /data/user/)
do

pm disable com.google.android.gms/.ads.AdRequestBrokerService
pm disable com.google.android.gms/.ads.GservicesValueBrokerService
pm disable com.google.android.gms/.ads.adinfo.AdvertisingInfoContentProvider
pm disable com.google.android.gms/.ads.config.FlagsReceiver
pm disable com.google.android.gms/.ads.config.GServicesChangedReceiver
pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdNotificationService
pm disable com.google.android.gms/.ads.identifier.service.AdvertisingIdService
pm disable com.google.android.gms/.ads.jams.NegotiationService
pm disable com.google.android.gms/.ads.jams.SystemEventReceiver
pm disable com.google.android.gms/.ads.measurement.GmpConversionTrackingBrokerService
pm disable com.google.android.gms/.ads.pan.PanService
pm disable com.google.android.gms/.ads.settings.AdsSettingsActivity
pm disable com.google.android.gms/.ads.social.DoritosReceiver
pm disable com.google.android.gms/.ads.social.GcmSchedulerWakeupService
pm disable com.google.android.gms/.analytics.AnalyticsReceiver
pm disable com.google.android.gms/.analytics.AnalyticsService
pm disable com.google.android.gms/.analytics.internal.GServicesChangedReceiver
pm disable com.google.android.gms/.analytics.internal.PlayLogReportingService
pm disable com.google.android.gms/.analytics.service.AnalyticsService
pm disable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService
pm disable com.google.android.gms/.analytics.service.RefreshEnabledStateService
pm disable com.google.android.gms/.auth.be.proximity.authorization.userpresence.UserPresenceService
pm disable com.google.android.gms/.backup.BackupStatsService
pm disable com.google.android.gms/.car.BroadcastRedirectActivity
pm disable com.google.android.gms/.car.CarErrorDisplayActivity
pm disable com.google.android.gms/.car.CarHomeActivity
pm disable com.google.android.gms/.car.CarHomeActivity1
pm disable com.google.android.gms/.car.CarHomeActivity2
pm disable com.google.android.gms/.car.CarIntentService
pm disable com.google.android.gms/.car.CarService
pm disable com.google.android.gms/.car.CarServiceSettingsActivity
pm disable com.google.android.gms/.car.FirstActivity
pm disable com.google.android.gms/.car.InCallServiceImpl
pm disable com.google.android.gms/.car.SetupActivity
pm disable com.google.android.gms/.car.VoiceActionService
pm disable com.google.android.gms/.car.diagnostics.CrashReporterService
pm disable com.google.android.gms/.checkin.CheckinService$ActiveReceiver
pm disable com.google.android.gms/.checkin.CheckinService$ClockworkFallbackReceiver
pm disable com.google.android.gms/.checkin.CheckinService$ImposeReceiver
pm disable com.google.android.gms/.checkin.CheckinService$SecretCodeReceiver
pm disable com.google.android.gms/.checkin.CheckinService$TriggerReceiver
pm disable com.google.android.gms/.checkin.EventLogService$Receiver
pm disable com.google.android.gms/.chimera.GmsIntentOperationService
pm disable com.google.android.gms/.common.analytics.CoreAnalyticsIntentService
pm disable com.google.android.gms/.common.analytics.CoreAnalyticsReceiver
pm disable com.google.android.gms/.common.stats.net.contentprovider.NetworkUsageContentProvider
pm disable com.google.android.gms/.config.ConfigService
pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionAsyncService
pm disable com.google.android.gms/.deviceconnection.service.DeviceConnectionServiceBroker
pm disable com.google.android.gms/.feedback.AnnotateScreenshotActivity
pm disable com.google.android.gms/.feedback.FeedbackActivity
pm disable com.google.android.gms/.feedback.FeedbackAsyncService
pm disable com.google.android.gms/.feedback.FeedbackConnectivityReceiver
pm disable com.google.android.gms/.feedback.FeedbackService
pm disable com.google.android.gms/.feedback.IntentListenerFeedbackActivity
pm disable com.google.android.gms/.feedback.LegacyBugReportService
pm disable com.google.android.gms/.feedback.PreviewActivity
pm disable com.google.android.gms/.feedback.PreviewScreenshotActivity
pm disable com.google.android.gms/.feedback.SendService
pm disable com.google.android.gms/.feedback.ShowTextActivity
pm disable com.google.android.gms/.feedback.SuggestionsActivity
pm disable com.google.android.gms/.fitness.disconnect.FitCleanupService
pm disable com.google.android.gms/.fitness.disconnect.FitDisconnectReceiver
pm disable com.google.android.gms/.fitness.sensors.activity.ActivityRecognitionService
pm disable com.google.android.gms/.fitness.sensors.floorchange.FloorChangeRecognitionService
pm disable com.google.android.gms/.fitness.sensors.sample.CollectSensorReceiver
pm disable com.google.android.gms/.fitness.sensors.sample.CollectSensorService
pm disable com.google.android.gms/.fitness.service.DebugIntentService
pm disable com.google.android.gms/.fitness.service.FitnessInitReceiver
pm disable com.google.android.gms/.fitness.service.ble.FitBleBroker
pm disable com.google.android.gms/.fitness.service.config.FitConfigBroker
pm disable com.google.android.gms/.fitness.service.history.FitHistoryBroker
pm disable com.google.android.gms/.fitness.service.internal.FitInternalBroker
pm disable com.google.android.gms/.fitness.service.proxy.FitProxyBroker
pm disable com.google.android.gms/.fitness.service.recording.FitRecordingBroker
pm disable com.google.android.gms/.fitness.service.sensors.FitSensorsBroker
pm disable com.google.android.gms/.fitness.service.sessions.FitSessionsBroker
pm disable com.google.android.gms/.fitness.settings.FitnessSettingsActivity
pm disable com.google.android.gms/.fitness.store.maintenance.StoreMaintenanceService
pm disable com.google.android.gms/.fitness.sync.FitnessContentProvider
pm disable com.google.android.gms/.fitness.sync.FitnessSyncAdapterService
pm disable com.google.android.gms/.fitness.wearables.WearableSyncService
pm disable com.google.android.gms/.fitness.wearables.WearableSyncServiceReceiver
pm disable com.google.android.gms/.googlehelp.GcmBroadcastReceiver
pm disable com.google.android.gms/.googlehelp.helpactivities.ClickToCallActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.EmailActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.HelpActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.OpenHangoutActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.OpenHelpActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.RealtimeSupportClassifierActivity
pm disable com.google.android.gms/.googlehelp.helpactivities.SystemAppTrampolineActivity
pm disable com.google.android.gms/.googlehelp.metrics.ConnectivityBroadcastReceiver
pm disable com.google.android.gms/.googlehelp.metrics.MetricsReportService
pm disable com.google.android.gms/.googlehelp.metrics.ReportBatchedMetricsService
pm disable com.google.android.gms/.googlehelp.service.ChatStatusUpdateService
pm disable com.google.android.gms/.googlehelp.service.ClearHelpHistoryIntentService
pm disable com.google.android.gms/.googlehelp.service.GoogleHelpService
pm disable com.google.android.gms/.googlehelp.service.VideoCallStatusUpdateService
pm disable com.google.android.gms/.googlehelp.webview.GoogleHelpWebViewActivity
pm disable com.google.android.gms/.kids.GcmReceiverService
pm disable com.google.android.gms/.kids.account.AccountRemovalConfirmActivity
pm disable com.google.android.gms/.kids.account.AccountSetupActivity
pm disable com.google.android.gms/.kids.account.ShowAppsActivity
pm disable com.google.android.gms/.kids.account.activities.RegisterProfileOwnerActivity
pm disable com.google.android.gms/.kids.account.receiver.ProfileOwnerReceiver
pm disable com.google.android.gms/.kids.chimera.AccountChangeReceiverProxy
pm disable com.google.android.gms/.kids.chimera.AccountSetupCompletedReceiverProxy
pm disable com.google.android.gms/.kids.chimera.AccountSetupServiceProxy
pm disable com.google.android.gms/.kids.chimera.DeviceTimeAndDateChangeReceiverProxy
pm disable com.google.android.gms/.kids.chimera.InternalEventReceiverLmpProxy
pm disable com.google.android.gms/.kids.chimera.InternalEventReceiverProxy
pm disable com.google.android.gms/.kids.chimera.KidsApiServiceProxy
pm disable com.google.android.gms/.kids.chimera.KidsDataProviderProxy
pm disable com.google.android.gms/.kids.chimera.KidsDataSyncServiceProxy
pm disable com.google.android.gms/.kids.chimera.KidsServiceProxy
pm disable com.google.android.gms/.kids.chimera.LongRunningServiceProxy
pm disable com.google.android.gms/.kids.chimera.PackageChangedReceiverProxy
pm disable com.google.android.gms/.kids.chimera.SlowOperationServiceProxy
pm disable com.google.android.gms/.kids.chimera.SystemEventReceiverProxy
pm disable com.google.android.gms/.kids.chimera.TimeoutsSystemAlertServiceProxy
pm disable com.google.android.gms/.kids.common.sync.ManualSyncReceiver
pm disable com.google.android.gms/.kids.creation.activities.FamilyCreationActivity
pm disable com.google.android.gms/.kids.device.RingService
pm disable com.google.android.gms/.measurement.PackageMeasurementTaskService
pm disable com.google.android.gms/.measurement.service.MeasurementBrokerService
pm disable com.google.android.gms/.nearby.bootstrap.service.NearbyBootstrapService
pm disable com.google.android.gms/.nearby.connection.service.NearbyConnectionsAndroidService
pm disable com.google.android.gms/.nearby.connection.service.NearbyConnectionsAsyncService
pm disable com.google.android.gms/.nearby.messages.NearbyMessagesBroadcastReceiver
pm disable com.google.android.gms/.nearby.messages.service.NearbyMessagesService
pm disable com.google.android.gms/.nearby.messages.settings.NearbyMessagesAppOptInActivity
pm disable com.google.android.gms/.nearby.settings.NearbyAccessActivity
pm disable com.google.android.gms/.nearby.settings.NearbyAppUninstallReceiver
pm disable com.google.android.gms/.nearby.settings.NearbySettingsActivity
pm disable com.google.android.gms/.nearby.sharing.service.NearbySharingService
pm disable com.google.android.gms/.perfprofile.uploader.PerfProfileCollectorService
pm disable com.google.android.gms/.perfprofile.uploader.RequestPerfProfileCollectionService
pm disable com.google.android.gms/.phenotype.receiver.PhenotypeBroadcastReceiver
pm disable com.google.android.gms/.phenotype.service.PhenotypeCommitService
pm disable com.google.android.gms/.phenotype.service.PhenotypeIntentService
pm disable com.google.android.gms/.phenotype.service.sync.PhenotypeConfigurator
pm disable com.google.android.gms/.phenotype.service.util.PhenotypeDebugService
pm disable com.google.android.gms/.photos.InitializePhotosIntentReceiver
pm disable com.google.android.gms/.photos.autobackup.AutoBackupWorkService
pm disable com.google.android.gms/.photos.autobackup.service.AutoBackupService
pm disable com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsActivity
pm disable com.google.android.gms/.photos.autobackup.ui.AutoBackupSettingsRedirectActivity
pm disable com.google.android.gms/.photos.autobackup.ui.LocalFoldersBackupSettings
pm disable com.google.android.gms/.photos.autobackup.ui.promo.AutoBackupPromoActivity
pm disable com.google.android.gms/.plus.activity.AccountSignUpActivity
pm disable com.google.android.gms/.plus.apps.ListAppsActivity
pm disable com.google.android.gms/.plus.apps.ManageAppActivity
pm disable com.google.android.gms/.plus.apps.ManageDeviceActivity
pm disable com.google.android.gms/.plus.apps.ManageMomentActivity
pm disable com.google.android.gms/.plus.audience.AclSelectionActivity
pm disable com.google.android.gms/.plus.audience.AudienceSearchActivity
pm disable com.google.android.gms/.plus.audience.CircleCreationActivity
pm disable com.google.android.gms/.plus.audience.CircleSelectionActivity
pm disable com.google.android.gms/.plus.audience.FaclSelectionActivity
pm disable com.google.android.gms/.plus.audience.UpdateActionOnlyActivity
pm disable com.google.android.gms/.plus.audience.UpdateCirclesActivity
pm disable com.google.android.gms/.plus.circles.AddToCircleConsentActivity
pm disable com.google.android.gms/.plus.oob.PlusActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountActivity
pm disable com.google.android.gms/.plus.oob.UpgradeAccountInfoActivity
pm disable com.google.android.gms/.plus.plusone.PlusOneActivity
pm disable com.google.android.gms/.plus.provider.PlusProvider
pm disable com.google.android.gms/.plus.service.DefaultIntentService
pm disable com.google.android.gms/.plus.service.ImageIntentService
pm disable com.google.android.gms/.plus.service.OfflineActionSyncAdapterService
pm disable com.google.android.gms/.plus.service.PlusService
pm disable com.google.android.gms/.plus.sharebox.AddToCircleActivity
pm disable com.google.android.gms/.plus.sharebox.ReplyBoxActivity
pm disable com.google.android.gms/.plus.sharebox.ShareBoxActivity
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdIntentService
pm disable com.google.android.gms/.pseudonymous.service.PseudonymousIdService
pm disable com.google.android.gms/.update.SystemUpdateService$ActiveReceiver
pm disable com.google.android.gms/.update.SystemUpdateService$OtaPolicyReceiver
pm disable com.google.android.gms/.update.SystemUpdateService$Receiver
pm disable com.google.android.gms/.update.SystemUpdateService$SecretCodeReceiver
pm disable com.google.android.gms/.usagereporting.service.UsageReportingService
pm disable com.google.android.gms/.usagereporting.settings.UsageReportingActivity
pm disable com.google.android.gms/.wallet.service.analytics.AnalyticsIntentService
pm disable com.google.android.gms/.wifi.gatherer2.receiver.GoogleAccountChangeReceiver
pm disable com.google.android.gms/.wifi.gatherer2.receiver.WifiStateChangeReceiver
pm disable com.google.android.gms/.wifi.gatherer2.service.GcmReceiverService
pm disable com.google.android.gms/.wifi.gatherer2.service.KeyManagerServce
pm disable com.google.android.gms/.wifi.gatherer2.service.WifiUpdateRetryTaskService
pm disable com.google.android.gms/com.google.android.contextmanager.service.ContextManagerService
pm disable com.google.android.gms/com.google.android.contextmanager.systemstate.SystemStateReceiver
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver
pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitor
pm disable com.google.android.gms/com.google.android.libraries.social.mediamonitor.MediaMonitorIntentService
pm disable com.google.android.gsf/.checkin.CheckinService
pm disable com.google.android.gsf/.checkin.EventLogService
pm disable com.google.android.gsf/.checkin.EventLogService$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateActivity
pm disable com.google.android.gsf/.update.SystemUpdatePanoActivity
pm disable com.google.android.gsf/.update.SystemUpdateService
pm disable com.google.android.gsf/.update.SystemUpdateService$Receiver
pm disable com.google.android.gsf/.update.SystemUpdateService$SecretCodeReceiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$Receiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$SecretCodeReceiver
pm disable com.google.android.gsf/com.google.android.gsf.checkin.CheckinService\$TriggerReceiver
pm enable com.google.android.gms/.checkin.CheckinService
pm enable com.google.android.gms/.checkin.EventLogService
pm enable com.google.android.gms/.common.stats.GmsCoreStatsService
pm enable com.google.android.gms/.common.stats.GmsCoreStatsServiceLauncher
pm enable com.google.android.gms/.phenotype.service.PhenotypeService
pm enable com.google.android.gms/.playlog.service.MonitorAlarmReceiver
pm enable com.google.android.gms/.playlog.service.MonitorService
pm enable com.google.android.gms/.playlog.service.PlayLogBrokerService
pm enable com.google.android.gms/.playlog.service.PlayLogIntentService
pm enable com.google.android.gms/.playlog.service.WallClockChangedReceiver
pm enable com.google.android.gms/.playlog.uploader.RequestUploadService
pm enable com.google.android.gms/.playlog.uploader.UploaderService
pm enable com.google.android.gms/.stats.PlatformStatsCollectorService
pm enable com.google.android.gms/.update.SystemUpdateService
done &> /dev/null

    # Add GMS to battery optimization
    dumpsys deviceidle whitelist -com.google.android.gms &> $NLL

sleep 20
su -lp 2000 -c "cmd notification post -S bigtext -t 'Từ Module' 'Tag' 'Cảm ơn bạn đã sử dụng Module này!!'"

echo " Tối ưu Google " >> /storage/emulated/0/Hải-tối-ưu.log

exit 0